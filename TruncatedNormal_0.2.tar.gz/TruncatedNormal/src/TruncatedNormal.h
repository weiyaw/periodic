/* Copyright (C) 2009 */
/* Berwin A Turlach <statba@nus.edu.sg> */

/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License along */
/* with this program; if not, write to the Free Software Foundation, Inc., */
/* 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA. */

/* The source of this file is inst/noweb/TruncatedNormal.nw   */

#ifndef BAT_TRUNCATEDNORMAL_H
#define BAT_TRUNCATEDNORMAL_H

#include <R.h>
#include <Rinternals.h>  
SEXP rtgauss(SEXP n, SEXP mean, SEXP sd, SEXP left, SEXP right) ;
Rboolean
generate_tgauss(double *x, R_len_t len_x, double mean, double sd,
                double left, double right);
#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext("TruncatedNormal", String)
#else
#define _(String) (String)
#endif  
#define M_SQRT_2PI   2.506628274631000502415765284811     /* sqrt(2pi) */
#define M_SQRT_E     1.648721270700128146848650787814     /* sqrt(e)   */  
#endif /* BAT_TRUNCATEDNORMAL_H */
