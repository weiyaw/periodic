/* Copyright (C) 2009 */
/* Berwin A Turlach <statba@nus.edu.sg> */

/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License along */
/* with this program; if not, write to the Free Software Foundation, Inc., */
/* 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA. */

/* The source of this file is inst/noweb/TruncatedNormal.nw   */

#include "TruncatedNormal.h"
static R_INLINE Rboolean
generate_gauss(double *x, R_len_t len_x, double mean, double sd);
static R_INLINE Rboolean
generate_rtgauss(double *x, R_len_t len_x, double mean, double sd,
                 double right);
static R_INLINE Rboolean
generate_ltgauss(double *x, R_len_t len_x, double mean, double sd,
                 double left);
static R_INLINE Rboolean
generate_btgauss(double *x, R_len_t len_x, double mean, double sd,
                 double left, double right);
SEXP
rtgauss(SEXP n, SEXP mean, SEXP sd, SEXP left, SEXP right){
    R_len_t len_n;
    double *ptr_ans;
    SEXP ans;
    R_len_t len_mean, len_sd, len_left, len_right;
    R_len_t i;
    double *ptr_mean, *ptr_sd, *ptr_left, *ptr_right;
    Rboolean naflag=FALSE;
    len_n = length(n);
    if( len_n == 1 ){
        len_n = asInteger(n); 
        if( len_n == NA_INTEGER || len_n < 0 ){
            error(_("argument 'n' invalid"));
        }
    }
    PROTECT(ans = allocVector(REALSXP, len_n));
    if( len_n == 0 ){
        UNPROTECT(1);
        return(ans);
    }
    ptr_ans = REAL(ans);
    len_mean = length(mean);  len_sd = length(sd);
    len_left = length(left);  len_right = length(right);
    if( len_mean < 1 || len_sd < 1 || len_left < 1 || len_right < 1 ){
        for(i = 0; i < len_n; i++, ptr_ans++)
            *ptr_ans = NA_REAL;
        warning(_("NAs produced"));
        UNPROTECT(1);
        return(ans);
    }
    ptr_mean = REAL(mean);   ptr_sd = REAL(sd);
    ptr_left = REAL(left);   ptr_right = REAL(right);
    if( len_n % len_mean )
        warning(_("'n' is not an integer multiple of 'length(mean)'"));
    if( len_n % len_sd )
        warning(_("'n' is not an integer multiple of 'length(sd)'"));
    if( len_n % len_left )
        warning(_("'n' is not an integer multiple of 'length(left)'"));
    if( len_n % len_right )
        warning(_("'n' is not an integer multiple of 'length(right)'"));
    GetRNGstate();
    if( len_mean == 1 && len_sd == 1 && len_left == 1 && len_right == 1 ){
        naflag = generate_tgauss(ptr_ans, len_n, *ptr_mean, *ptr_sd,
                                 *ptr_left, *ptr_right);
    }else{
        for(i = 0; i < len_n; i++, ptr_ans++)
            naflag = generate_tgauss(ptr_ans, 1, ptr_mean[i % len_mean],
                                     ptr_sd[i % len_sd],
                                     ptr_left[i % len_left],
                                     ptr_right[i % len_right]);
    }
    if( naflag )
        warning(_("NAs produced"));
    PutRNGstate();
    UNPROTECT(1);
    return(ans);    
}
Rboolean
generate_tgauss(double *x, R_len_t len_x, double mean, double sd,
                double left, double right){
    R_len_t i;
    int method;
    Rboolean naflag = FALSE;
    if( ISNAN(mean) || ISNAN(left) || ISNAN(right) || !R_FINITE(sd)
        || sd < 0. || right < left ){
        for(i= 0; i < len_x; i++, x++)
            *x = NA_REAL;
        return(TRUE);
    }
    method = R_FINITE(left)*2 + R_FINITE(right); 
    switch (method){
    case 0:
        if( left == right ){
            for(i= 0; i < len_x; i++, x++)
                *x = NA_REAL;
            return(TRUE);
        }
        naflag = generate_gauss(x, len_x, mean, sd);
        break;
    case 1:
        naflag = generate_rtgauss(x, len_x, mean, sd, right);
        break;
    case 2:
        naflag = generate_ltgauss(x, len_x, mean, sd, left);
        break;
    case 3:
        naflag = generate_btgauss(x, len_x, mean, sd, left, right);
        break;
    default:
        error(_("How did we reach this point?"));
    }
    return(naflag);
}
static R_INLINE Rboolean
generate_gauss(double *x, R_len_t len_x, double mean, double sd){
    Rboolean naflag = FALSE;
    R_len_t i;
    if ( sd == 0. || !R_FINITE(mean)){
        for(i = 0; i < len_x; i++, x++)
            *x = mean;
        return( FALSE );
    }else{
        for(i = 0; i < len_x; i++, x++){
            *x = mean + sd * norm_rand();
            if( ISNAN(*x) ) naflag = TRUE;
        }
    }
    return( naflag );
}
static R_INLINE Rboolean
generate_rtgauss(double *x, R_len_t len_x, double mean, double sd,
                 double right){
    R_len_t i;
    Rboolean naflag = FALSE;
    naflag = generate_ltgauss(x, len_x, -mean, sd, -right);
    for(i = 0; i < len_x; i++, x++)
        *x = - (*x);
    return(naflag);
}
static R_INLINE Rboolean
generate_ltgauss(double *x, R_len_t len_x, double mean, double sd,
                 double left){
    R_len_t i;
    Rboolean naflag=FALSE;
    double leftZ;
    double proposal, *ptr_x;
    double astar, tmp;
    if ( sd == 0. || !R_FINITE(mean) ){
        if( left <= mean ){
            for(i = 0; i < len_x; i++, x++)
                *x = mean;
            return( FALSE );
        }else{
            for(i= 0; i < len_x; i++, x++)
                *x = NA_REAL;
            return(TRUE);
        }
    }
    leftZ = (left - mean)/sd;
    if( !R_FINITE(leftZ) ){
        warning(_("mean (%e), sd (%e) and left (%e) are too extreme"),
                mean, sd, left);
        for(i= 0; i < len_x; i++, x++)
            *x = NA_REAL;
        return(TRUE);
    }
    if( leftZ < 0 ){
        ptr_x = x;
        for(i = 0; i < len_x; i++, ptr_x++){
            do{
                proposal = norm_rand();
            }while( proposal < leftZ );
            *ptr_x = proposal;
        }
    }else{
        if( leftZ < 2.0 ){
            tmp = leftZ / 2.0;
            astar = tmp + sqrt(tmp*tmp+1.0);
        }else{
            tmp = 2.0 / leftZ;
            astar = leftZ * (1.0 + sqrt(1.0 + tmp*tmp))/ 2.0;
        }
        ptr_x = x;
        for(i = 0; i < len_x; i++, ptr_x++){
            do{
                proposal = leftZ + exp_rand() / astar ;
                tmp = proposal - astar;
                tmp = -tmp*tmp/2.0;
            }while( log(unif_rand()) > tmp );
            *ptr_x = proposal;
        }        
    }
    for(i = 0; i < len_x; i++, x++){
        *x = mean + sd * (*x);
        if( ISNAN(*x) ) naflag = TRUE;
    }
    return(naflag);
}
static R_INLINE Rboolean
generate_btgauss(double *x, R_len_t len_x, double mean, double sd,
                 double left, double right){
    R_len_t i;
    Rboolean naflag=FALSE;
    double leftZ, rightZ;
    double rng;
    double proposal,*ptr_x;
    double tmp;    
    double astar;
    double tmp1;
    Rboolean flipsign = FALSE;
    if( sd == 0. || !R_FINITE(mean) ){
        if( (left <= mean) && (mean <= right) ){
            for(i = 0; i < len_x; i++, x++)
                *x = mean;
            return( FALSE );
        }else{
            for(i= 0; i < len_x; i++, x++)
                *x = NA_REAL;
            return(TRUE);
        }
    }
    if( left == right ){
        for(i = 0; i < len_x; i++, x++)
            *x = left;
        return(FALSE);
    }
    leftZ = (left - mean)/sd;
    rightZ = (right - mean)/sd;
    if( !R_FINITE(leftZ) || !R_FINITE(rightZ) ){
      warning(_("mean (%e), sd (%e), left (%e) and right (%e) are too extreme"),
              mean, sd, left, right);
      for(i= 0; i < len_x; i++, x++)
          *x = NA_REAL;
      return(TRUE);
    }
    if( ( leftZ*rightZ < 0. ) ){
        rng = rightZ - leftZ;
        if( rng > M_SQRT_2PI ){
            ptr_x = x;
            for(i = 0; i < len_x; i++, ptr_x++){
                do{
                    proposal = norm_rand();
                }while ( (proposal < leftZ) || (proposal > rightZ) );
                *ptr_x = proposal;
            }
        }else{
            ptr_x = x;
            for(i = 0; i < len_x; i++, ptr_x++){
                do{
                    proposal = leftZ + rng*unif_rand();
                    tmp = - proposal*proposal/2.0;
                }while( log(unif_rand()) > tmp );
                *ptr_x = proposal;
            }
        }

    }else{
        if ( rightZ <= 0.0 ){
            tmp = leftZ; leftZ = -rightZ; rightZ = -tmp;
            flipsign = TRUE;
        }
        if ( leftZ < 2.0 ){
            tmp = leftZ / 2.0;
            astar = tmp + sqrt(tmp*tmp+1.0);
        }else{
            tmp = 2.0 / leftZ;
            astar = leftZ * (1.0 + sqrt(1.0 + tmp*tmp))/2.0;
        }
        tmp1 = leftZ + M_SQRT_E/astar * exp(-leftZ/(2*astar));
        if( rightZ > tmp1 ){
            ptr_x = x;
            for(i = 0; i < len_x; i++, ptr_x++){
                do{
                    proposal = leftZ + exp_rand() / astar ;
                    tmp = proposal - astar;
                    tmp = -tmp*tmp/2.0;
                }while( (proposal > rightZ) || (log(unif_rand()) > tmp) );
                *ptr_x = proposal;
            }
        }else{
            ptr_x = x;
            rng = rightZ - leftZ;
            for(i = 0; i < len_x; i++, ptr_x++){
                do{
                    tmp = rng * unif_rand();
                    proposal = leftZ + tmp;
                    tmp *= -(leftZ+proposal)/2.0;
                }while( log(unif_rand()) > tmp );
                *ptr_x = proposal;
            }
        }
    }
    if(flipsign){
      for(i = 0; i < len_x; i++, x++){
        *x = mean - sd * (*x);
        if( ISNAN(*x) ) naflag=TRUE;
      }
    }else{
      for(i = 0; i < len_x; i++, x++){
        *x = mean + sd * (*x);
        if( ISNAN(*x) ) naflag=TRUE;
      }
    }
    return(naflag);
}
