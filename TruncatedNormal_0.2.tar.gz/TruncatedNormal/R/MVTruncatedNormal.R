## "-*- mode: R -*- "
## Copyright (C) 2009
## Berwin A Turlach <statba@nus.edu.sg>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License along
## with this program; if not, write to the Free Software Foundation, Inc.,
## 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

## The source of this file is inst/noweb/MVTruncatedNormal.nw

rmvtgauss.lin <- function(n, mu, Sigma, PrecMat=FALSE, factorised = FALSE, 
                          Amat, Avec, 
                          start, burnin = 1, thin = 1){

    if( length(n) == 1 ){
      n <- as.integer(n)
    }else{
      n <- length(n)
    }
    if( is.na(n) || n < 0 )
      stop("argument 'n' invalid")

    if( missing(mu) ){
      stop("argument 'mu' is missing with no default")
    }
    mu <- as.numeric(mu)
    d <- length(mu)
    if( missing(Sigma) ){
      stop("argument 'Sigma' is missing with no default")
    }
    Sigma <- as.matrix(Sigma)
    if( missing(Amat) ){
      stop("argument 'Amat' is missing with no default")
    }    
    Amat <- as.matrix(Amat)
    if( missing(Avec) ){
      stop("argument 'Avec' is missing with no default")
    }
    Avec <- as.numeric(Avec)

    if( missing(start))
      start <- rep(0,d)
    start <- as.numeric(start)

    if( length(burnin) > 1 ){
      warning("'burnin' has length > 1; using first component")
      burnin <- as.numeric(burnin[1])
    }
    if( length(thin) > 1 ){
      warning("'thin' has length > 1; using first component")
      thin <- as.numeric(thin[1])
    }
    
    if( !is.numeric(Sigma) || !is.numeric(Amat) ||
       !is.numeric(burnin) || !is.numeric(thin) )
      stop("some arguments are not numeric")
    if( any(is.na(mu)) || any(is.na(Sigma)) || any(is.na(Amat)) ||
       any(is.na(Avec)) || any(is.na(start)) || is.na(burnin) || is.na(thin) )
      stop("some arguments contain NAs")
    
    if( !isTRUE(all.equal(dim(Sigma), c(d,d))) )
      stop("arguments 'mu' and 'Sigma' are incompatible")
    if( length(start) != d )
      stop("arguments 'mu' and 'start' are incompatible")
    if( NROW(Amat) != d )
      stop("arguments 'mu' and 'Amat' are incompatible")
    if( NCOL(Amat) != length(Avec) )
      stop("arguments 'Amat' and 'Avec' are incompatible")
  if(!factorised){
    Sigma <- chol(Sigma)
  }
  if(PrecMat){
    Bmat <- backsolve(Sigma, Amat, transpose=TRUE)
  }else{
    Bmat <- Sigma %*% Amat
  }
  Bvec <- Avec - crossprod(Amat, mu)

  if(PrecMat){
    start <- as.vector(Sigma %*% (start-mu))
  }else{
    start <- backsolve(Sigma, start-mu, transpose=TRUE)
  }
  
  res <- matrix(NA, nrow=d, ncol=n)

  for(i in 1:burnin){
    tmpmat <- start * Bmat
    for(dd in 1:d){
      tmpvec <- Bvec - colSums(tmpmat[-dd, , drop=FALSE])
      ind <- Bmat[dd, , drop=FALSE] > 0
      if( sum(ind) > 0 ){
        left <- max(tmpvec[ind]/Bmat[dd,ind])
      }else{
        left <- -Inf
      }
      ind <- Bmat[dd, , drop=FALSE] < 0
      if( sum(ind) > 0 ){
        right <- min(tmpvec[ind]/Bmat[dd,ind])
      }else{
        right <- Inf
      }
      if(left > right)
        stop("inconsistent constraints")
      start[dd] <- rtgauss(1, left=left, right=right)
      tmpmat[dd, ] <- start[dd] * Bmat[dd, , drop=FALSE]
    }
  }
  res[,1] <- start
  if( n > 1){
    for(i in 2:n){
      for(j in 1:thin){
        tmpmat <- start * Bmat
        for(dd in 1:d){
          tmpvec <- Bvec - colSums(tmpmat[-dd, , drop=FALSE])
          ind <- Bmat[dd, , drop=FALSE] > 0
          if( sum(ind) > 0 ){
            left <- max(tmpvec[ind]/Bmat[dd,ind])
          }else{
            left <- -Inf
          }
          ind <- Bmat[dd, , drop=FALSE] < 0
          if( sum(ind) > 0 ){
            right <- min(tmpvec[ind]/Bmat[dd,ind])
          }else{
            right <- Inf
          }
          if(left > right)
            stop("inconsistent constraints")
          start[dd] <- rtgauss(1, left=left, right=right)
          tmpmat[dd, ] <- start[dd] * Bmat[dd, , drop=FALSE]
        }
      }
      res[,i] <- start
    }
  }

  if(PrecMat){
    res <- backsolve(Sigma, res) + mu
  }else{
    res <- crossprod(Sigma, res) + mu
  }
  res
}
