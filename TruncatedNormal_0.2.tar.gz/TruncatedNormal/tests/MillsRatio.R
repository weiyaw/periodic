library(TruncatedNormal)

MR <- function(x, log=FALSE){
  res <- pnorm(x, lower=FALSE, log=TRUE) - dnorm(x, log=TRUE)
  if( log ){
    return(res)
  }else{
    return(exp(res))
  }
}

xl <- list(seq(from=-5, to=5, length=1000),
           runif(1000)*10 -5,
           seq(from=-37.519, to=37.519, length=1000),
           runif(1000)*75.038 - 37.519)
for(x in xl){
  for( log in c(TRUE, FALSE) ){
    t1 <- MR(x, log=log)
    t2 <- MillsRatio(x, log=log)
    print(all.equal(t1, t2))
  }
}

MillsRatio(c(-Inf, Inf))
MillsRatio(c(-Inf, Inf), log=TRUE)
MillsRatio(c(NA, NaN))
MillsRatio(c(NA, NaN), log=TRUE)

x <- c(10^(0:40), Inf)
MillsRatio(x)
MillsRatio(x, log=TRUE)

x <- c(-1.1^(0:40), -Inf)
MillsRatio(x)
MillsRatio(x, log=TRUE)

MillsRatio(numeric(0))
MillsRatio(numeric(0), log=TRUE)
