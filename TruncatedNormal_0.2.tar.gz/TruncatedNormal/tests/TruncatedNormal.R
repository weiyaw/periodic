library(TruncatedNormal)
set.seed(20090224)

####### various tests for rtgauss #############################

### tests on inputs for 'n' 
try(rtgauss(-4))
rtgauss(0)
rtgauss(numeric(0))

### tests for n being larger than other arguments
rtgauss(3, mean=c(1,2))
rtgauss(3, sd=c(1,2))
rtgauss(3, left=c(1,2))
rtgauss(3, right=c(1,2))

### tests for n being smaller than other arguments
rtgauss(2, mean=1:5)
rtgauss(3, sd=1:5)
rtgauss(4, left=1:5)
rtgauss(3, right=1:5)

### tests for other arguments having zero length
rtgauss(3, mean=numeric(0))
rtgauss(3, sd=numeric(0))
rtgauss(3, left=numeric(0))
rtgauss(3, right=numeric(0))


### tests for special values
rtgauss(3, mean=NA)
rtgauss(3, sd=NA)
rtgauss(3, sd=Inf)
rtgauss(3, left=NA)
rtgauss(3, right=NA)
rtgauss(3, left=10, right=-10)

### tests for other extreme cases
rtgauss(3, mean=3, sd=0)
rtgauss(3, mean=3, sd=0, left=-1)
rtgauss(3, mean=3, sd=0, left= 4)
rtgauss(3, mean=3, sd=0, right=-1)
rtgauss(3, mean=3, sd=0, right=4)
rtgauss(3, mean=Inf, sd=0)
rtgauss(3, mean=Inf, sd=0, left=-1)
rtgauss(3, mean=Inf, sd=0, left= 4)
rtgauss(3, mean=Inf, sd=0, right=-1)
rtgauss(3, mean=Inf, sd=0, right=4)
rtgauss(3, mean=-Inf, sd=0)
rtgauss(3, mean=-Inf, sd=0, left=-1)
rtgauss(3, mean=-Inf, sd=0, left= 4)
rtgauss(3, mean=-Inf, sd=0, right=-1)
rtgauss(3, mean=-Inf, sd=0, right=4)
rtgauss(3, mean=Inf, sd=3)
rtgauss(3, mean=Inf, sd=3, left=-1)
rtgauss(3, mean=Inf, sd=3, left= 4)
rtgauss(3, mean=Inf, sd=3, right=-1)
rtgauss(3, mean=Inf, sd=3, right=4)
rtgauss(3, mean=-Inf, sd=3)
rtgauss(3, mean=-Inf, sd=3, left=-1)
rtgauss(3, mean=-Inf, sd=3, left= 4)
rtgauss(3, mean=-Inf, sd=3, right=-1)
rtgauss(3, mean=-Inf, sd=3, right=4)


### test for untruncated case
rtgauss(3)
rtgauss(4, mean=c(1,2))
rtgauss(3, mean=c(1,2))
mean(tt <- rtgauss(300000))
sd(tt)
range(tt)
hist(tt, prob=TRUE)

### tests for routine for left truncation
for(left in c(-2, -1.5, -1, -0.5, -0.2, 0, 0.5, 1.5, 2.5, 3.5)){
  mean(tt <- rtgauss(300000, left=left))
  sd(tt)
  range(tt)
  hist(tt, prob=TRUE)
  stopifnot(all(tt >= left))
}

rtgauss(4, sd=1e-160, left=1e160)

### tests for routine for right truncation
for(right in c(2, 1.5, 1, 0.5, 0.2, 0, -0.5, -1.5, -2.5, -3.5)){
  mean(tt <- rtgauss(300000, right=right))
  sd(tt)
  range(tt)
  hist(tt, prob=TRUE)
  stopifnot(all(tt <= right))
}

rtgauss(4, sd=1e-160, right=1e160)

### tests for routines for truncation on both side
#### extreme inputs
rtgauss(3, mean=3, sd=0, left=4, right=4)
rtgauss(3, mean=4, sd=0, left=4, right=4)
rtgauss(3, mean=4, sd=1, left=4, right=4)
rtgauss(3, mean=6, sd=1, left=4, right=4)
rtgauss(3, mean=6, sd=1, left=-4, right=-4)

#### sampling with normal proposal
left <- -1.3
right <- 1.3
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))

left <- -2
right <- 2
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))

left <- -2
right <- 2
mean <- 30
mean(tt <- rtgauss(300000, mean=mean, left=mean+left, right=mean+right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
tt <- tt-mean
stopifnot(all(left <= tt & tt <= right))

#### sampling with uniform proposal 1
left <- -1
right <- 1
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))

left <- -0.5
right <- 0.5
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))

left <- -1
right <- 0.5
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))

#### sampling with truncated normal proposal
left <- 0
right <- 2
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

left <- 0.5
right <- 2.5
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

left <- 2.0
right <- 2.5
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

#### sampling with uniform proposal 2

left <- 0.0
right <- 1.0
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

left <- 1.5
right <- 2.0
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

left <- 2.0
right <- 2.1
mean(tt <- rtgauss(300000, left=left, right=right))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(left <= tt & tt <= right))
mean(tt <- rtgauss(300000, left=-right, right=-left))
sd(tt)
range(tt)
hist(tt, prob=TRUE)
stopifnot(all(-right <= tt & tt <= -left))

rtgauss(4, sd=1e-160, left=-1e160, right=0)
rtgauss(4, sd=1e-160, left=0, right=1e160)
